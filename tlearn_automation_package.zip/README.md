# Tlearn NEET/AMSIT Video Automation Pipeline

This project automates 3D cartoon video creation with Colab, Sheets, and GitHub integration.
